

const getYear = () => {
    return new Date().getFullYear();
}

const gethola = () => {
    return 'Hola mundo';
}



module.exports = {
    getYear: getYear,
    gethola: gethola,
}
